package publicdomain_thebarnswallowclub;


import java.util.Random;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author steph
 */
public class NobleMath {
    public static int randomInt() {
        Random rand1 = new Random();
        int seed = rand1.nextInt();
        Random rand2 = new Random(seed);
        return rand2.nextInt();
        
    }
    
    public static int randomInt(int beginRange, int endRange) {
        Random rand1 = new Random();
        int seed = rand1.nextInt();
        Random rand2 = new Random(seed);
        double num = rand2.nextDouble();
        double range = (double) (endRange-beginRange);
        double randRange = num*range+(double) beginRange;
        return (int) randRange;
        
        
    }
    
    public static int randomInt(int beginRange, int endRange,int seed) {
        Random rand1 = new Random(seed);
        int seed1 = rand1.nextInt();
        Random rand2 = new Random(seed1);
        double num = rand2.nextDouble();
        double range = (double) (endRange-beginRange);
        double randRange = num*range+(double) beginRange;
        return (int) randRange;
        
        
    }
    
    public static double Pi() {
        double dx = 0.000000001;
        double cos = java.lang.Math.pow(1.0-java.lang.Math.cos(java.lang.Math.toRadians(dx)), 2.0);
        double sin = java.lang.Math.pow(java.lang.Math.sin((java.lang.Math.toRadians(dx))), 2.0);
        double ydy = java.lang.Math.pow(cos+sin,0.5)*180.0/dx;
        System.out.println("->" +ydy);
        return ydy;
    }
    /**
     * 
     * @param factor
     * @return 
     */
    public static double Pi(double factor) {
        double dx = 0.000000001/factor;
        double cos = java.lang.Math.pow(1.0-java.lang.Math.cos(java.lang.Math.toRadians(dx)), 2.0);
        double sin = java.lang.Math.pow(java.lang.Math.sin((java.lang.Math.toRadians(dx))), 2.0);
        double ydy = java.lang.Math.pow(factor*factor*(cos+sin),0.5)*180.0/dx;
        
        
        return ydy;
    }
    /**
     * A challenge to frighten the hearts of men: Barns and The Wallow Collective
     */
    public static void outputNums() {
        double factor = 1.0;
        double dx = 0.000000001/factor;
        double cos = java.lang.Math.pow(1.0-java.lang.Math.cos(java.lang.Math.toRadians(dx)), 2.0);
        double sin = java.lang.Math.pow(java.lang.Math.sin((java.lang.Math.toRadians(dx))), 2.0);
        double ydy = java.lang.Math.pow(factor*factor*(cos+sin),0.5)*180.0/dx;
        String piString = "" + ydy;
        int index = piString.indexOf(".");
        String piNum = piString.substring(index-1,index);
        int num = (int) ydy*(int)factor*10;
        factor = 1.0;
        System.out.println( ydy);    
        System.out.println( piNum);
        for (int i = 1;i <= 10;i++) {
            
            dx = 0.000000001/factor;
            cos = java.lang.Math.pow(1.0-java.lang.Math.cos(java.lang.Math.toRadians(dx)), 2.0);
            sin = java.lang.Math.pow(java.lang.Math.sin((java.lang.Math.toRadians(dx))), 2.0);
            
            piString = "" + ydy;
            index = piString.indexOf(".");
            piNum = piString.substring(index-1,index);
            num = num-Integer.parseInt(piNum);
            factor = factor*10.0;
            ydy = java.lang.Math.pow(factor*factor*(cos+sin),0.5)*180.0/dx- (int) num;
            factor = factor*10.0;
            System.out.println( num);
            System.out.println( ydy);
            System.out.println( piNum);
        }
    }
    public static double piApprox() {
        double pi = 6.97433569568173/2.2200000015;
        return pi;
    }
    /**
     * finds the ratio of an irational number needs some work
     * Barns Nobel, The Barns Wallow Collective
     * @param Target
     * @param Tolerance
     * @return 
     */
    public static double theMathinator(double Target,double Tolerance) {
        double pi = 0.0;
        //Target = 3.141592653589793;
        double firstBlush = Target*0.9999975;
        double denominator = 222.00000015;
        double numerator = denominator*firstBlush;
        int count = 0;
        numerator = (numerator*10.0)-1.0;
        denominator = denominator*10.0;
        int iter = 12;
        double tolerance = 0.001;
        for (int i = 0;i < iter;i++) {
            boolean close = false;
            
            for (double n = numerator;n < denominator*(firstBlush*2.0);n=n+4.0) {
                
                count++;
                if (count== 1000000000) {
                    System.out.println(n);
                    count = 0;
                }
                double piTest = n/denominator;

                if (Target - piTest < Tolerance) {
                    numerator = n;
                    n = denominator*1000.0;
                    System.out.println("Hello There!");
                    tolerance = tolerance/10.0;
                    
                }
            }
            if (tolerance < 0.0000000000001) {
                        break;
            } else {
                System.out.println(numerator/denominator);
                numerator = numerator*10.0-Target;
                denominator = denominator*10.0;
                System.out.println(numerator/denominator);
                
            }
            
        }
        System.out.println("Numerator: "+numerator);
        System.out.println("Denominaor: "+denominator);
        System.out.println("PI: "+numerator+"/"+denominator);
        System.out.println("PI: "+(numerator/denominator));
        return numerator/denominator;
    }
    
    public static char randomChar(int seed) {
        Random rand1 = new Random(seed);
        int seed2 = rand1.nextInt();
        Random rand2 = new Random(seed2);
        double d = rand2.nextDouble();
        return (char)((int) d*(255.1));
        
        
    }
}
