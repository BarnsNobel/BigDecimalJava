
import java.math.BigDecimal;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public abstract class BigDecimalManipulation {
    public static boolean lessThan(BigDecimal one, BigDecimal two) {
       double test = two.subtract(one).doubleValue();
       if (test < 0.0) {
           return false;
       }
       return true;
   }
   
   public static boolean lessThanEqaulTo(BigDecimal one, BigDecimal two) {
       double test = two.subtract(one).doubleValue();
       if (test < 0.0) {
           return false;
       } else if (test == 0.0) {
           return true;
       }
       return true;
   }
   
   public static boolean greaterThan(BigDecimal one, BigDecimal two) {
       double test = one.subtract(two).doubleValue();
       if (test < 0.0) {
           return false;
       }
       return true;
   }
   
   public static boolean greaterThanOrEqualTo(BigDecimal one, BigDecimal two) {
       double test = one.subtract(two).doubleValue();
       if (test < 0.0) {
           return false;
       } else if (test == 0.0) {
           return true;
       }
       return true;
   }
   
   public static int getExponent(BigDecimal number) {
       int exponent = (int) Math.log10(number.doubleValue());
       return exponent;
       
   }
   
   
}
