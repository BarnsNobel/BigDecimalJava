/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub.localResourceFolder;

import java.awt.Color;
import publicdomain_thebarnswallowclub.*;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.BufferedReader;
import java.io.File;
import static publicdomain_thebarnswallowclub.TARDISBASECODESKILLLEVELONEHUNDREDPERCENT.outputCommandToSys;
import static publicdomain_thebarnswallowclub.Utilities.closeBufferedReader;
import static publicdomain_thebarnswallowclub.Utilities.openTxtFile;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public abstract class ImageUtilitiesTIMELORD {
    //prototype
    public static BufferedImage MatrixRuntimeCharacterRebel(char cout) {
        Font f = new Font("Noto JP Thin", Font.PLAIN, 50);
        int blur = (int) (NobleMath.piApprox());
        BufferedImage blury = new BufferedImage(f.getSize()+50+blur,f.getSize()+50+blur, BufferedImage.TYPE_4BYTE_ABGR);
        
        while (!(f.canDisplay(cout))) {
            cout = 'Z';
        }
        String s = String.valueOf(cout);
        Graphics2D g2 = blury.createGraphics();
        g2.setFont(f);
        g2.setColor(new Color(120,255,120));
        FontMetrics fm = g2.getFontMetrics();
        int sw = fm.charWidth(cout);
        int sh = fm.getAscent()+fm.getDescent();
        g2.drawString(s, blury.getWidth()/2-sw/2, blury.getHeight()/2
                +sh/2);
        WritableRaster raster =  blury.getRaster();
        
        
        for (int x = 0;x < blury.getWidth()-blur;x++) {
            for (int y = 0; y < blury.getHeight()-blur;y++) {
                //average the square
                int red = 0;
                int green = 0;
                int blue = 0;
                int alpha = 0;
                
                for (int x2 = x;x2 < x+blur;x2++) {
                    for (int y2 = y;y2 < y+blur;y2++) {
                        int[] pixIn = new int[4];
                        raster.getPixel(x2, y2,pixIn);
                        red += pixIn[0];
                        green += pixIn[1];
                        blue += pixIn[2];
                        alpha += pixIn[3];
                    }
                }
                red = red/(blur*blur);
                green = green/(blur*blur);
                blue = blue/(blur*blur);
                alpha = alpha/(blur*blur);
                
                
               for (int x2 = x;x2 < x+blur;x2++) {
                    for (int y2 = y;y2 < y+blur;y2++) {
                        int[] pixOut = new int[]{red,255,blue,alpha};
                        raster.setPixel(x2, y2, pixOut);
                    }
                }
               
               
               
               
            }
        }
        
        //File file = Utilities.createLocalResource(fileName+"."+Utilities.PNG);
        //Utilities.exportImage(blury, file, Utilities.PNG);
        return blury;
    }
    
    public static void readAndExecuteCommandFile(File plainTxtFile, File output) {
        BufferedReader buffReader = openTxtFile(plainTxtFile);
        char cout = ' ';
        
        int c = 0;
        int count = 0;
        while (c != -1) {
            try {
               c = buffReader.read();
               if (c != -1) {
                   cout = (char) c;
                   count++;
                   BufferedImage image = MatrixRuntimeCharacterRebel(cout);
                   
               }
            } catch(Exception ex) {
                closeBufferedReader(buffReader);
                System.out.println("Caught Exception in reading file: "+ex.getMessage());
                break;
            }
        }
        
    }
    
    
    
}



