/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public class BernsNobelBooksofWisdom {
    public BernsNobelBooksofWisdom() {
        String[] array = new String[15];
        array[0] = "New Wine";
        array[1] = "Old Wine";
        array[2] = "Diamond Mine";
        array[3] = "Secret Messages";
        array[4] = "Secrets of the Color Code";
        array[5] = "Secrets of Success";
        array[6] = "Of religion and sorcery";
        array[7] = "A class on Java: level 1";
        array[8] = "On Wormholes and time travel: spaceflight";
        array[9] = "On taoism (Daoism) vs Christianity";
        array[10] = "On Sex, Dating, Mating and Reproducing";
        array[11] = "On genetics and emergant species Homo libertus";
        array[12] = "On Greek philosphy and Christianity";
        array[13] = "On the emergence of the new species Homo Abicus";
        array[14] = "On the expansion to mars, Homo Sapien, Homo Libertus, Homo Abicus";
        
        int choice = InputListener.menu(array);
        
        if (choice == -1) {
            exit();
        } else if (choice == 9) {
            spaceflightAndWormholes();
        } else if (choice == 7) {
            BookofReconciliatonMagicAndMen magic = new BookofReconciliatonMagicAndMen();
        }
        exit();
    }
    private void spaceflightAndWormholes() {
        System.out.println("Take A Flight in Hybernation: Goal Planet Bob 20 light years away");
        String[] array = {"Maybe Later", "No go away", "Wormhole 1000 years away"};
        int choice = InputListener.menu(array);
        if (choice == 1) {
            System.out.println("Humanity goes extict or finds another way to the stars");
            System.out.println("Bad luck fritz");
            exit();
        } else if (choice == 2) {
            System.out.println("Humanity goes extict or finds andother way to the stars.");
            System.out.println("Bad luck fritz");
            exit();
        } else if (choice == 3) {
             System.out.println("Good choice. Planet Bob is 3 weeks away from the other end of the wormhole; +1000 years");
            System.out.println("Now for the return trip to Earth");
            String[] array2 = {"Wormhole 3 weeks away", "Wormhole 600 years away", "Wormhole 1000 years away"};
            choice = InputListener.menu(array2);
            if (choice == 1) {
                System.out.println("Okay Return to Earth: 2000 yrs + 6 weeks from departure: Everyone has forgot about you! They Shoot you out of the sky.");
                System.out.println("Bad luck fritz");
                exit();
            } else if (choice == 2) {
                System.out.println("Wormhole deposits you 100 yrs from earth");
                System.out.println("Okay Return to Earth: 1100 yrs + 6 weeks from departure: Everyone has forgot about you! They Shoot you out of the sky.");
                System.out.println("Bad luck fritz");
                exit();
            } else if (choice == 3) {
                System.out.println("Good choice. Planet Earth is 3 weeks away from the other end of the wormhole; +1000 years");
                System.out.println("2000 years total + 3 weeks");
                System.out.println("Only the wormhole takes you 2000 yrs into the past: Do You take it.");   
                String[] array3 = new String[]{"NO DEFINATLY NOT FIND ANOTHER WAY!", "Nearest Wormhole 200 yrs", "Yes, for sure take it."};
                choice = InputListener.menu(array3);
                if (choice == 1) {
                    System.out.println("Good Luck Chuck. Hope you find your way Home. 2000 yrs + 3 Weeks into the voyage.");
                    exit();
                } else if (choice == 2) {
                    System.out.println("Failed to find viable route: Marooned: 2200 yrs + 3 weeks");
                    exit();
                } else if (choice == 3) {
                    System.out.println("Good Choice: total travel time: 2000 yrs + 3 weeks - 2000 yrs + 3 weeks");
                    System.out.println("Travel Time: 6 weeks, Arrival back to Earth: 6 weeks after departure.");
                    exit();
                }
            }
        }
    }
    private void exit() {
        System.out.println("System Exit.");
        System.exit(0);
    }
}
