/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public class WishesAndKissesClub {
      public WishesAndKissesClub() {
          System.out.println("For the religious, and irreligious alike.");
          System.out.println("Wishes and Kisses Club: Say a prayer");
          System.out.println("Throw a dollar on the beach.");
          System.out.println("Say another prayer, while turning three times.");
          System.out.println("Kiss the person you are closest to.");
          System.out.println("Make a wish: and watch what happens.");
          System.out.println("Wish:");
          
          String wish = InputListener.readLine("Make your wish, if you dare.");
          System.out.println(wish+"." + " Wish Granted.");
          
          
          
      }
}
