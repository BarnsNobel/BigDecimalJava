/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import javax.imageio.ImageIO;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public class Utilities {
    public static final String PNG = "png";
    public static final String JPG = "jpg";
    public static final String PDF = "pdf";
    public static final String JPG2000 = "jpg";
    public static BufferedImage importImage(File imageFile) {
        BufferedImage image =  null;
        try {
            image =  ImageIO.read(imageFile);
        } catch(Exception ex) {
            System.out.println("Caught Exception reading Image: "+ ex.getMessage());
        }
        return image;
    }
    //needs to be tested for pdf future considerations if not
    public static void exportImage(BufferedImage image,File exportImageFile, String UtilsFormat) {
        
        try {
            ImageIO.write(image, UtilsFormat, exportImageFile);
        } catch(Exception ex) {
            System.out.println("Caught Exception exporting image: "+ ex.getMessage());
        }
    }
    public static BufferedReader openTxtFile(File txtFile) {
        FileReader reader = null;
        BufferedReader buffReader = null;
        try {
            reader = new FileReader(txtFile);
            buffReader = new BufferedReader(reader);
            String line = buffReader.readLine();
            buffReader.close();
            reader.close();
            
            reader = new FileReader(txtFile);
            buffReader = new BufferedReader(reader);
        } catch(Exception ex) {
            System.out.println("Caught Exception opening txt file: "+ ex.getMessage());
            System.exit(0);
        }
        
        if (buffReader == null) {
             System.out.println("Caught Exception opening txt file: failed to create stream.");
             System.exit(0);
        }
        
        return buffReader;
    }
    
    public static void closeBufferedReader(BufferedReader buffReader) {
        
    }
    public static File locateLocalResource(String filename) {
        String pack = Utilities.class.getPackageName();
        
        String name = "src\\"+pack+"\\localResourceFolder\\"+filename;
        return new File(name);
    }
    
    public static File createLocalResource(String filename) {
        String pack = Utilities.class.getPackageName();
        
        String name = "src\\"+pack+"\\localResourceFolder\\"+filename;
        File file = new File(name);
        try {
            file.delete();
            file.createNewFile();
        } catch(Exception ex) {
            System.out.println("Caught Exception creating resource file: "+ ex.getMessage());
            System.exit(0);
        }
        return file;
    }
    
    
    
}
