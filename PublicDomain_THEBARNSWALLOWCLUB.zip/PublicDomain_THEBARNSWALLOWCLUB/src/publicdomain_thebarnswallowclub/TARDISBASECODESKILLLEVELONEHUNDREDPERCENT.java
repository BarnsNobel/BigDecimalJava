/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub;

import java.awt.Font;
import java.io.BufferedReader;
import java.io.File;
import java.io.PrintWriter;
import java.util.Calendar;
import static publicdomain_thebarnswallowclub.Utilities.closeBufferedReader;
import static publicdomain_thebarnswallowclub.Utilities.openTxtFile;
import publicdomain_thebarnswallowclub.localResourceFolder.ImageUtilitiesTIMELORD;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public abstract class TARDISBASECODESKILLLEVELONEHUNDREDPERCENT {
    public static void runCommands() {
        //defineTest();
        //testOutput("test byte grab");
        
        //reboot();
        
    }
    public static void testOutput(String normalStringTOBETESTED) {
        
        System.out.println("|test... 1"+normalStringTOBETESTED+"\\ end.");
        System.out.println("|test... 1A"+normalStringTOBETESTED+"\\ end.");
        try {
            
            System.out.println("|test... 2"+normalStringTOBETESTED+"\\ end.");
            
        } catch(Exception ex) {
            System.out.println("ex: "+ex.getMessage());
        }
    }
    public static void outputCommandToSys(String command) {
        System.out.println(command);
    }
    public static void outputCommand(PrintWriter out, String command) {
        try {
            System.out.println(command);
            out.println(command);
        } catch(Exception ex) {
            System.out.println("ex: "+ex.getMessage());
        }
    } 
    public static void readAndTestCommandFile(File plainTxtFile) {
        BufferedReader buffReader = openTxtFile(plainTxtFile);
        String line = " ";
        while (line != null) {
            try {
                line = buffReader.readLine();
                testOutput(line);
            } catch(Exception ex) {
                closeBufferedReader(buffReader);
                System.out.println("Caught Exception in reading tcom file: "+ex.getMessage());
                break;
            }
        }
        
    }
    public static void readAndExecuteCommandFile(File plainTxtFile) {
        BufferedReader buffReader = openTxtFile(plainTxtFile);
        String line = " ";
        while (line != null) {
            try {
                line = buffReader.readLine();
                outputCommandToSys(line);
            } catch(Exception ex) {
                closeBufferedReader(buffReader);
                System.out.println("Caught Exception in reading tcom file: "+ex.getMessage());
                break;
            }
        }
        
    }
    public static void executeCommand(String command) {
        System.out.println("\\"+command+".");
    }
    public static void executeCommand(int command) {
        System.out.println("|"+command+".");
    }
    public static PrintWriter createPrintWriter(String newFile) {
        File file = Utilities.createLocalResource(newFile);
        PrintWriter stream = null;
        try {
            stream = new PrintWriter(file);
        } catch(Exception ex) {
            System.out.println("Caught Exception in creating stream: "+ex.getMessage());
            return null;
        }
        return stream;
    }
    public static PrintWriter getPrintWriter(String tcomFile) {
        File file = Utilities.createLocalResource(tcomFile);
        PrintWriter stream = null;
        try {
            stream = new PrintWriter(file);
        } catch(Exception ex) {
            System.out.println("Caught Exception in creating stream: "+ex.getMessage());
            return null;
        }
        return stream;
    }
    public static void outputTimestampAndSignature(PrintWriter out,String name) {
        int hash = name.hashCode();
        Calendar c = Calendar.getInstance();
        long timeMili = c.getTimeInMillis();
        int r = NobleMath.randomInt(0, Integer.MAX_VALUE, hash);
        long r2 = NobleMath.randomInt(0, Integer.MAX_VALUE, hash/2);
        String code = name+"-"+hash+"-"+timeMili+"="+r+"-"+r2+"-"+(timeMili-r2);
        System.out.println(code);
        out.println(code);
    }
    
    public static void reboot() {
        
        PrintWriter out = getPrintWriter("TARDIS DATABASE FILE Aditional "
                + "Gods.tcom.txt");
        outputCommand(out,"\\God Cleopatrah, ra, rah, *rah, egyption, god, new to christ, to world, welcome back,"
        + "sun god, genesis, great light to govern the day, see egyption history web God");
        outputCommand(out,"\\God Norse, gods, sea, sea, lightning, air..., real, God,"
                + " more..., history, oral, cultures, decide whom you will serve.,"
                + " Barns Tiberius Nobel, Time Lord, in service to humanity and The Time Lord Council.");
        outputCommand(out,"end.");
        outputTimestampAndSignature(out,"Barns Nobel");
        outputCommand(out,"end.");
        outputTimestampAndSignature(out,"Barns Nobel");
        outputCommand(out,"end.");
        outputTimestampAndSignature(out,"Barns Nobel");
        outputCommand(out,"end.");
        outputCommand(out,"eof.");
        try {
            out.close();
        } catch(Exception ex) {
            System.out.println("Caught Exeption in command file output: "+ex.getMessage());
        }
        
        
        
        
    }   
}
