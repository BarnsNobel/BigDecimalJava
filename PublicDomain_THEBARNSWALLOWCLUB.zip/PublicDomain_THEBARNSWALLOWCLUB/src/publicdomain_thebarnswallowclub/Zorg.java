/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public class Zorg {
    public Zorg() {
        String[] array = new String[]{"W", "E", "N"};
        int choice = InputListener.menu(array);
        if (choice == 1) {
            System.out.println("You choose wisely a path awaits.");
            Level1W();
        }else if (choice == 2) {
            System.out.println("You choose poorly fight or die.");
            Level1E();
        }else if (choice == 3) {
            System.out.println("Nothing happened. Maybe you should make a better choice nect time.");
            Level1N();
        }else if (choice == -1) {
            Exit();
        }
        Exit();
    }
    public static void Exit() {
        System.out.println("You choose wisely to exit the game.");
        System.exit(0);
    }
    public static void Level1W() {
        //the way forward awaits...
        System.out.println("The way forward awaits.");
        System.out.println("Stay Tuned to this channel for more exiting news.");
        System.out.println("...");
        Exit();
    }
    public static void Level1E() {
        String[] array = new String[]{"Fight", "Flee"};
        int choice = InputListener.menu(array);
        if (choice == 1) {
            array = new String[]{"Water", "Hammer"};
            choice = InputListener.menu(array);
            if (choice == 1) {
                System.out.println("Congratulations You Win! The Water Evaporating Donkey has been vanquishd!");
                Exit();
            } else {
                Exit();
            }
        } else {
            Exit();
        }
        
    }
    public static void Level1N() {
        String[] array = new String[]{"W", "E", "N"};
        int choice = InputListener.menu(array);
        if (choice == 1) {
            System.out.println("You choose wisely a path awaits.");
            Level1W();
        }else if (choice == 2) {
            System.out.println("You choose poorly fight or die.");
            Level1E();
        }else if (choice == 3) {
            System.out.println("Nothing happened. Maybe you should make a better choice nect time.");
            Exit();
        }else if (choice == -1) {
            Exit();
        }
    }
    
}
