package publicdomain_thebarnswallowclub;


import java.io.File;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *Formally known as the Color Code Barns Nobel, The Barns Wallow Collective
 * @author Barns Noble, marked as Public Domain
 */
public class TheColorZip {
    int r =0;
    int g = 0;
    int b = 0;
    int a = 0;
    
    int x = 0;
    int y = 0;
    File[] fileArray = null;
    File outDir = null;
            
    public TheColorZip(File[] imageOrWebFiles, File outputDirectory) {
        fileArray = imageOrWebFiles;
        outDir = outputDirectory;
    }
}
