package publicdomain_thebarnswallowclub;

import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public abstract class ImageFilters {
    public static BufferedImage dotMatrix(BufferedImage image) {
        for (int x = 0;x < image.getWidth();x+=5) {
            for (int y = 0;y < image.getHeight();y+=5) {
                for (int i = 0; i < 255;i+=5) {
                    WritableRaster raster =image.getRaster();
                    double average = 0.0;
                    
                    for(int xP = x; xP < x+5;xP++) {
                        for (int yP = y; yP < y+5;yP++) {
                            
                            int[] pix = new int[3];
                            raster.getPixel(xP, yP, pix);
                            average = average + pix[0]+pix[1]+pix[2];
                            
                        }
                    }
                    average = average;
                    
                    
                    int aver = (int) (average/20.0) + (int)((average-50.0)/80.0);
                    if (aver< 0) {
                        aver = 0;
                    }
                    int[] pix = new int[]{aver,aver,aver};
                    
                    for(int xP = x; xP < x+5;xP++) {
                        for (int yP = y; yP < y+5;yP++) {
                            
                            raster.setPixel(xP, yP, pix);
                            
                        }
                    }
                    
                }
            }
        }
        return image;
        
    }
    
    
}
