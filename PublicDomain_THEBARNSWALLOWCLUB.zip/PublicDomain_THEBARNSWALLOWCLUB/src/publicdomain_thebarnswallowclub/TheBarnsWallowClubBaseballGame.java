/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public class TheBarnsWallowClubBaseballGame {
    public TheBarnsWallowClubBaseballGame(File file) {
        String message = "Are You Sure:";
        System.out.println(message);
        message = "Play Ball? Some Files may be deleted(Cannot Be Undone).";
        System.out.println(message);
        String[] areYouSure = new String[] {"Yes","No","Think Upon Your Sins and Exit."};
        int choice = InputListener.menu(areYouSure);
        if (choice == 1) {
            //perm delte file
            
            try {
                FileReader fr = new FileReader(file);
                int size = 0;
                while (fr.read() != -1) {
                    size++;
                }
                fr.close();
                for (int i = 0; i < 5;i++) {
                    FileWriter fw = new FileWriter(file);
                    int marker = 0;
                    while (marker < size) {
                        int rand = NobleMath.randomInt(0, 255);
                        fw.write(rand);
                        marker++;
                    }
                    fw.close();
                }
                file.delete();
                message = "hOME RRuN MSEG delETED. I am melting down now G..d Bye.";
                System.out.println(message);
                System.out.println("Exit. System.");
                System.exit(0);
            } catch(Exception ex) {
                System.out.println("Error: " + ex.getMessage());
            }
        } else if (choice == 3) {
            message = "Your sins are many, think and repent.";
            System.out.println(message);
            System.exit(0);
        } else {
            message = "Good. Choice. System. Reboot.";
            System.out.println(message);
            
            try {
            ProcessBuilder builder = new ProcessBuilder(
            "cmd.exe", "/c","shutdown -r");
            builder.redirectErrorStream(true);
            builder.start();
            } catch(Exception ex) {
                message = "Bad. Choice. System. Reboot.";
                System.out.println(message+" "+ex.getMessage());
                
            }
            
            //console.writer().println();
            
        }
        
    }
}
