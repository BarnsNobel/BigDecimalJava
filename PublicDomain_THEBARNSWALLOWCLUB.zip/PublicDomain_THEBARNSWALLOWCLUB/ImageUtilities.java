/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub;

import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public abstract class ImageUtilities {
    //prototype
    public static BufferedImage blur(double blurAmout, BufferedImage image) {
        BufferedImage blury = new BufferedImage(450,450, BufferedImage.OPAQUE);
        Font f = new Font("Noto Sans JP Thin", Font.PLAIN, 300);
        int r = NobleMath.randomInt(0, 16*16*16*16+1);
        String c = String.valueOf((char) r);
        Graphics2D g2 = blury.createGraphics();
        g2.setFont(f);
        g2.drawString(c, 50, 350);
        WritableRaster raster =  blury.getRaster();
        
        
        File file = Utilities.createLocalResource("test");
        Utilities.exportImage(blury, file, Utilities.JPG);
        return blury;
    }
}
