/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub;

import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;
import static com.sun.java.accessibility.util.AWTEventMonitor.addWindowListener;
import java.awt.Frame;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public class KeyboardListener extends Frame {
    public static String input = "";
    public KeyboardListener() {

        System.out.println("KeyListener Active: press ESC to exit:");
        
        
        WindowAdapter winList = new WindowAdapter(){
            
            public void windowClosing(WindowEvent e) {
                System.out.println("KeyListener Exited."); 
                System.exit(0);
                 
            }
            public void windowClosed(WindowEvent e) {
                System.out.println("KeyListener Exited.");
                System.exit(0);
            }
            
        };
        
    
        KeyAdapter keyListener = new KeyAdapter(){    
            public void keyPressed(KeyEvent ke) {
                String s ="" +ke.getKeyChar();
                try {
                System.out.print(s);
                }catch(Exception ex) {}
                if (ke.getKeyChar() == KeyEvent.VK_ESCAPE) {
                    System.out.println("Exited.");
                    System.exit(0);

                } else if (ke.getKeyChar() == KeyEvent.VK_ENTER) {
                    //TODO CODE HERE line return
                    //input equals the line of text read
                    //put manipulation of string input here
                    String line = input;
                    System.out.println(line);
                    
                    
                    //clear the variable
                    input = "";

                } else {
                    
                    input = input + ke.getKeyChar();
                    

                }


            }
        };
        
        addWindowListener(winList);
        setUndecorated(true);
        addKeyListener(keyListener);
        setVisible(true);
    }
            
}
