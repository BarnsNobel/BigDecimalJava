/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub;

import java.awt.event.KeyEvent;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public abstract class InputListener  {
    
    public static String readLine(String message) {
        System.out.println(message+" and press Enter:");
        
        String input = "";
        int count = 0;
        boolean done = false;
        try {
            while (!(done)) {
                
                byte[] in = System.in.readNBytes(1);
                char s = (char) in[0];
                if (String.valueOf(s).contains("\n")) {
                    
                    return input;
                }   else {
                    input = input + String.valueOf(s);
                    count++;
                }
            }
        } catch(Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        
        return input;
    }  
    
    public static int menu(String[] options) {
        int selection = -1;
        for (int i = 0;i < options.length;i++) {
            System.out.println(""+(i+1)+": "+ options[i]);
        }
        System.out.println(""+(options.length+1)+": Exit");
        boolean answer = false;
        while (!(answer)) {
            String input = readLine("Enter Menu Selection:");
            try {
                selection = Integer.parseInt(input);
                if (selection > options.length+1) {
                    answer = false;
                } else {
                    answer = true;
                }
            } catch(Exception ex) {
                answer = false;
            }
        }
        if (selection == options.length+1) {
            selection = -1;
        }
        return selection;
    }
}
