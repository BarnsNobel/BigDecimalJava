/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package publicdomain_thebarnswallowclub;

import java.io.File;

/**
 *
 * @author steph
 */
public class PUBLICDOMAIN {
    public PUBLICDOMAIN() {
        //MatrixUPC.upcImageCharacter(0);
        //TARDISBASECODESKILLLEVELONEHUNDREDPERCENT.runCommands();
        //MatrixUPC.upcImageCharacter(94);
        //ImageUtilities.blur(10.0, null);
        //WishesAndKissesClub prayer = new WishesAndKissesClub();
        //KeyboardListener keyboardListener = new KeyboardListener();
        //InputListener list = new InputListener();
        /*String[] array = new String[]{"W", "E", "N"};
        int choice = InputListener.menu(array);
        if (choice == 1) {
            System.out.println("You choose wisely a path awaits.");
        }else if (choice == 2) {
            System.out.println("You choose poorly fight or die.");
        }else if (choice == 3) {
            System.out.println("Nothing happened. Maybe you should make a better choice nect time.");
            
        }else if (choice == -1) {
            System.out.println("You choose wisely to exit the game.");
        }*/
        //String input = InputListener.readLine("Enter Input");
        //Zorg z = new Zorg();
        //BernsNobelBooksofWisdom magicSpellsOfTheMostDeliciousKind = new BernsNobelBooksofWisdom();
        TheBarnsWallowClubBaseballGame delte = new TheBarnsWallowClubBaseballGame(new File("C:\\Users\\steph\\OneDrive\\Desktop\\UPCIMAGES\\test.png"));
    
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         PUBLICDOMAIN BarnsWallow = new PUBLICDOMAIN();
    }
    
}
