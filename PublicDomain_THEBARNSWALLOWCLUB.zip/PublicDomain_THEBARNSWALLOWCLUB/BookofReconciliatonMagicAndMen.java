/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package publicdomain_thebarnswallowclub;

/**
 * A Barns Swallow Club project....
 * Credit to Bethany Harmon and Taylor Swift for there inspiration and help.
 * @author Barns Nobel, Marked as public Domain, 2022,2023.....Medicine Hat, AB. 2023.
 */
public class BookofReconciliatonMagicAndMen {
    public BookofReconciliatonMagicAndMen() {
        int x = 15;
        String[] magic = new String[x];
        magic[x-magic.length] = "Magic: the power to move objects with the mind.";
        magic[x-magic.length+1] = "Magic the power to move objects through time.";
        magic[x-magic.length+2] = "Magic the power to inspire others";
        magic[x-magic.length+3] = "Magic the power to control earth wind fire";
        magic[x-magic.length+4] = "Magic the power of sugesstion";
        magic[x-magic.length+5] = "Magic: transform objects from one to another";
        magic[x-magic.length+6] = "Spells of all kinds.";
        magic[x-magic.length+7] = "Potons and elixors";
        magic[x-magic.length+8] = "Written word";
        magic[x-magic.length+9] = "this is a discussion, not a solution.";
        magic[x-magic.length+10] = "Anything can be abused and the middle path.";
        magic[x-magic.length+11] = "";
        magic[x-magic.length+12] = "";
        magic[x-magic.length+13] = "An apology from the King of kings and the Lord or Lords \n"
                + "I will do everything in my power to make it right especiallly get him to church where he belongs."
                + ""
                + "(Pentalcostal) the romans dont want him, lol. good luck you two. Jesus and the saints.\n";
        magic[x-magic.length+14] = "A New Role: The creation pf the Jedi Order: Who watches the watchers \n"
                + "ie: who watches the police the fibbys the fibbys watch themselms soo who watches the watchers \n"
                + "we are all fallible time has shown us this and only He is above reproach. So Again I ash who watches the watchers? \n"
                + "the witchcreaft guild. Thats who. With my deepest thanks and appologies on the tardiness of this response."
                + "\n my strength and admiration to Hermes Hermignie, I am still sure I spelled that wrong. Stephen Wilson."
                + "\n Christian ambassdor to the Witchcraft Guild. \n (now know As Barns T. Nobel the first.)";
        
    
        for (int i = 0;i < magic.length;i++) {
            System.out.println(magic[i]);
        }
    
    }
    
    
    
}
